# Deploying Core AI to production

Core AI is a **single Node.js process with zero npm dependencies** (pure Node
built-ins). It stores all state as JSON files in `data/` (and user uploads in
`uploads/`). That makes deployment very simple — but it also means two things:

1. **You need a persistent disk** so `data/` survives restarts/redeploys.
2. **Run exactly one instance.** The JSON store is not shared across processes
   (no horizontal scaling yet). For a real multi-user product, migrate `lib/store.js`
   to Postgres — see “Scaling up” below.

Pick ONE of the three paths below.

---

## Path A — Docker on a PaaS (easiest, recommended first launch)

Works with **Railway, Render, Fly.io, DigitalOcean App Platform, Northflank**.
All give you a free/small tier and a public HTTPS URL automatically.

### Railway (simplest, has free trial)
1. Push this folder to a GitHub repo.
2. Go to https://railway.app → **New Project → Deploy from GitHub repo**.
3. Railway auto-detects the `Dockerfile` and deploys.
4. Add a **Volume** mounted at `/app/data` (and optionally `/app/uploads`)
   so data persists.
5. Under **Variables**, set `COREAI_SECRET` (run `openssl rand -hex 32`).
6. Click your service → **Generate Domain** → done, you get `https://…app`.

### Render (free web service tier)
1. Push to GitHub → render.com → **New → Web Service**.
2. Select the repo. Runtime: **Docker**.
3. Add a **Persistent Disk** mounted at `/app/data` (Render mounts disks at a
   path you choose; also mount `/app/uploads` if you want file storage).
4. Add env vars: `COREAI_SECRET` (generate with `openssl rand -hex 32`).
5. Deploy — Render gives you `https://…onrender.com`.

> Free-tier PaaS instances **sleep after inactivity** (cold start ~30–60s).
> That's fine for a demo. Paid plans keep it always-on.

---

## Path B — Bare Node + PM2 on a VPS (most control, ~$5/mo)

Works with **Hetzner, DigitalOcean Droplet, Linode, AWS Lightsail, Vultr**.
Choose Ubuntu 22.04+.

```bash
# 1. Install Node 20
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs nginx

# 2. Install PM2 (process manager: auto-restart, start on boot)
sudo npm i -g pm2

# 3. Upload the app to the server
scp -r server.js lib public package.json user@your-server:/opt/core-ai
#   (or: git clone your repo into /opt/core-ai)

# 4. Run it
cd /opt/core-ai
mkdir -p data uploads/files
export COREAI_SECRET=$(openssl rand -hex 32)
pm2 start ecosystem.config.js
pm2 save && pm2 startup        # auto-start on reboot

# 5. Reverse proxy + HTTPS
sudo tee /etc/nginx/sites-available/core-ai > /dev/null <<'NGINX'
server {
    listen 80;
    server_name your-domain.com;

    location / {
        proxy_pass http://127.0.0.1:8080;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
    }
}
NGINX

sudo ln -s /etc/nginx/sites-available/core-ai /etc/nginx/sites-enabled/
sudo nginx -t && sudo systemctl reload nginx

# 6. Free HTTPS certificate (Let's Encrypt)
sudo apt-get install -y certbot python3-certbot-nginx
sudo certbot --nginx -d your-domain.com
```

Point `your-domain.com` at the server's IP (DNS A record) first.

---

## Path C — Local machine / quick share (no host at all)

```bash
cd /home/user          # wherever the app lives
node server.js         # → http://localhost:8080
```
To let someone else reach it temporarily, use a tunnel:
```bash
npx localtunnel --port 8080     # or: cloudflared tunnel --url http://localhost:8080
```

---

## Pre-launch checklist (do these before real users)

| Item | Why |
|---|---|
| `COREAI_SECRET` set (env, not in repo) | Credentials are encrypted with it; changing it later makes stored keys unreadable |
| Persistent disk for `data/` + `uploads/` | PaaS instances without a volume lose everything on redeploy |
| Back up `data/*.json` nightly | `cron`: `tar czf backup-$(date +%F).tgz /opt/core-ai/data` |
| Remove demo accounts (`demo@coreai.app`) | In `data/users.json`, or wipe `data/` for a clean launch |
| Put a CDN/edge in front later | Cloudflare (free) → HTTPS, caching, DDoS protection |

---

## Scaling up (when you outgrow one box)

The app is deliberately dependency-free, so the main production limitation is
the JSON-file store. When you have real users:

1. **Database** — swap `lib/store.js` (the `Store` class) for a Postgres or
   SQLite adapter. Every route calls `store.get/set/del/all`, so only that one
   file changes.
2. **Queue** — the workflow engine runs in-process; move it to a worker +
   Redis/BullMQ queue for long-running automations.
3. **Auth** — the current session tokens are server-side (`data/sessions.json`);
   you can add OAuth (Google/GitHub) or keep email login.

---

## Files included for deployment

| File | Purpose |
|---|---|
| `Dockerfile` | Container build (tiny, no deps) |
| `package.json` | Node engines + `npm start` |
| `ecosystem.config.js` | PM2 config (auto-restart) |
| `.env.example` | Env vars template |
| `.dockerignore` | Keeps runtime state out of the image |
