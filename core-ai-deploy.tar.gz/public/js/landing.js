(function () {
  // Mobile nav
  const burger = document.getElementById('hamburger');
  const links = document.getElementById('navLinks');
  if (burger && links) {
    burger.addEventListener('click', () => links.classList.toggle('open'));
  }

  // Pricing toggle
  const toggle = document.getElementById('pricingToggle');
  if (toggle) {
    toggle.addEventListener('click', (e) => {
      const btn = e.target.closest('button');
      if (!btn) return;
      toggle.querySelectorAll('button').forEach((b) => b.classList.remove('active'));
      btn.classList.add('active');
      const period = btn.dataset.period;
      document.querySelectorAll('.plan .amt[data-monthly]').forEach((el) => {
        el.textContent = period === 'yearly' ? el.dataset.yearly : el.dataset.monthly;
      });
      document.querySelectorAll('.plan-billed').forEach((el) => {
        if (el.dataset.yearly) el.textContent = period === 'yearly' ? el.dataset.yearly : el.dataset.monthly;
      });
    });
  }

  // Open the live demo widget
  const openDemo = document.getElementById('openDemo');
  if (openDemo && window.CoreAIWidget) {
    openDemo.addEventListener('click', () => window.CoreAIWidget.open());
  }

  // Embed the REAL demo chatbot widget (trained on Core AI's knowledge base)
  if (window.CoreAIWidget) {
    window.CoreAIWidget.init({ chatbotId: 'demo' });
  }
})();
