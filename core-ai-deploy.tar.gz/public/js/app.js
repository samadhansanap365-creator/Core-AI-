'use strict';
/* ============================================================
   Core AI — dashboard single-page app
   ============================================================ */
(function () {
  const $ = (s, r) => (r || document).querySelector(s);
  const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));

  const state = {
    token: (function () {
      let t = '';
      try { t = new URLSearchParams(location.search).get('tok') || ''; } catch (e) {}
      if (!t) { try { t = localStorage.getItem('coreai_token') || ''; } catch (e) {} }
      if (!t) { try { t = sessionStorage.getItem('coreai_token') || ''; } catch (e) {} }
      if (!t) {
        try {
          const m = document.cookie.match(/(?:^|;\s*)coreai_token=([^;]+)/);
          if (m) t = decodeURIComponent(m[1]);
        } catch (e) {}
      }
      return t;
    })(),
    user: null,
    chatbots: [],
    bot: null,
    route: null,
    conversations: [],
  };

  const SWATCHES = ['#6366f1', '#8b5cf6', '#7c3aed', '#4f46e5', '#0ea5e9', '#06b6d4', '#10b981', '#f59e0b', '#ef4444', '#ec4899', '#0f172a'];
  const LOGOS = ['✦', '🤖', '💬', '⚡', '🟣', '🔷', '🧠', '🚀', '🎯', '🛎️', '💡', '🌟'];

  // ---------------- helpers ----------------
  function esc(s) {
    return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }
  function toast(msg, type) {
    const wrap = $('#toasts');
    const t = document.createElement('div');
    t.className = 'toast ' + (type || '');
    t.textContent = msg;
    wrap.appendChild(t);
    setTimeout(() => { t.style.opacity = '0'; t.style.transition = 'opacity .3s'; setTimeout(() => t.remove(), 320); }, 3200);
  }
  function modal(html) {
    const bd = document.createElement('div');
    bd.className = 'modal-backdrop';
    bd.innerHTML = '<div class="modal">' + html + '</div>';
    document.body.appendChild(bd);
    bd.addEventListener('click', (e) => { if (e.target === bd) bd.remove(); });
    return {
      el: bd,
      close: () => bd.remove(),
      content: $('.modal', bd),
    };
  }
  function ago(ts) {
    if (!ts) return '—';
    const d = new Date(ts);
    const s = Math.floor((Date.now() - d.getTime()) / 1000);
    if (s < 60) return 'just now';
    if (s < 3600) return Math.floor(s / 60) + 'm ago';
    if (s < 86400) return Math.floor(s / 3600) + 'h ago';
    if (s < 86400 * 30) return Math.floor(s / 86400) + 'd ago';
    return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  }
  function fmtDate(ts) {
    return ts ? new Date(ts).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) : '—';
  }
  function fmtTime(ts) {
    return ts ? new Date(ts).toLocaleString('en-US', { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' }) : '—';
  }
  function initials(name) {
    return (name || '?').split(/\s+/).map((w) => w[0]).join('').slice(0, 2).toUpperCase();
  }

  // ---------------- API ---------------- 
  // In sandboxed preview iframes, localStorage/cookies can be blocked AND the
  // proxy can strip Authorization/x-session headers. We detect that and fall
  // back to carrying the session token as a ?tok= query parameter instead.
  let useQueryAuth = false;
  (function () {
    try {
      localStorage.setItem('__coreai_probe', '1');
      if (localStorage.getItem('__coreai_probe') !== '1') useQueryAuth = true;
      localStorage.removeItem('__coreai_probe');
    } catch (e) { useQueryAuth = true; }
  })();

  function setSession(token) {
    state.token = token;
    try { localStorage.setItem('coreai_token', token); } catch (e) { useQueryAuth = true; }
    try { sessionStorage.setItem('coreai_token', token); } catch (e) {}
    try { document.cookie = 'coreai_token=' + encodeURIComponent(token) + ';path=/;max-age=86400;SameSite=Lax'; } catch (e) { useQueryAuth = true; }
  }
  function clearSession() {
    state.token = null;
    try { localStorage.removeItem('coreai_token'); } catch (e) {}
    try { sessionStorage.removeItem('coreai_token'); } catch (e) {}
    try { document.cookie = 'coreai_token=;path=/;max-age=0'; } catch (e) {}
  }
  function cookieToken() {
    try {
      const m = document.cookie.match(/(?:^|;\s*)coreai_token=([^;]+)/);
      return m ? decodeURIComponent(m[1]) : '';
    } catch (e) { return ''; }
  }

  let authBounced = false;
  async function api(path, opts) {
    opts = opts || {};
    opts.headers = Object.assign({}, opts.headers);
    if (state.token) {
      opts.headers['Authorization'] = 'Bearer ' + state.token;
      opts.headers['x-session'] = state.token;
    }
    if (opts.body && typeof opts.body === 'object') {
      opts.body = JSON.stringify(opts.body);
      opts.headers['Content-Type'] = 'application/json';
    }
    let url = '/api' + path;
    if (state.token && useQueryAuth) url += (url.includes('?') ? '&' : '?') + 'tok=' + encodeURIComponent(state.token);
    let r;
    try {
      r = await fetch(url, opts);
    } catch (e) {
      return { status: 0, data: { error: 'Network error — is the server running?' } };
    }
    let data = {};
    try { data = await r.json(); } catch (e) { data = { error: 'bad_response' }; }
    if (r.status === 401 && state.token && !useQueryAuth) {
      // We hold a token but the server rejected the headers — the proxy is
      // likely stripping them. Switch to query-param auth and retry once.
      useQueryAuth = true;
      const q = '/api' + path + (path.includes('?') ? '&' : '?') + 'tok=' + encodeURIComponent(state.token);
      try { r = await fetch(q, opts); } catch (e) { return { status: 0, data: { error: 'Network error — is the server running?' } }; }
      try { data = await r.json(); } catch (e) { data = {}; }
    }
    if (r.status === 401) {
      if (!state.token) return { status: r.status, data }; // login failure → caller shows error
      if (!authBounced) {
        // Session expired → clear and re-provision a guest session once.
        authBounced = true;
        clearSession();
        location.replace('/app');
      }
    }
    return { status: r.status, data };
  }

  async function boot() {
    if (!state.token) { state.token = cookieToken(); if (state.token) { try { localStorage.setItem('coreai_token', state.token); } catch (e) {} } }
    if (!state.token) return false;
    let r = await api('/me');
    for (let i = 0; i < 4 && r.status === 0; i++) { await new Promise((s) => setTimeout(s, 500)); r = await api('/me'); }
    if (r.status === 200 && r.data.user) {
      state.user = r.data.user;
      await loadChatbots();
      return true;
    }
    if (r.status === 0) return true; // server hiccup: don't log out, keep showing shell
    clearSession();
    return false;
  }

  async function loadChatbots() {
    let r = await api('/chatbots');
    if (r.status !== 200) r = await api('/chatbots'); // one retry for transient hiccups
    if (r.status === 200) state.chatbots = r.data.chatbots || [];
  }

  async function loadBot(botId) {
    const r = await api('/chatbots/' + botId);
    if (r.status === 200) state.bot = r.data.chatbot;
    return state.bot;
  }

  function handoffCount() {
    if (!state.chatbots.length) return 0;
    let n = 0;
    for (const b of state.chatbots) n += (b._handoffs || 0);
    return n;
  }

  // ---------------- router ----------------
  function parseRoute() {
    const h = location.hash.replace(/^#\/?/, '').split('?')[0];
    const parts = h.split('/').filter(Boolean);
    if (parts.length === 0) return { view: 'overview' };
    if (parts[0] === 'plans') return { view: 'plans' };
    if (parts[0] === 'api') return { view: 'api' };
    if (parts[0] === 'account') return { view: 'account' };
    if (parts[0] === 'b' && parts[1]) return { view: 'bot', botId: parts[1], tab: parts[2] || 'overview' };
    return { view: 'overview' };
  }

  const BOT_TABS = [
    { id: 'overview', label: 'Overview', ico: '📊' },
    { id: 'training', label: 'Training', ico: '🧠' },
    { id: 'appearance', label: 'Appearance', ico: '🎨' },
    { id: 'personality', label: 'Personality', ico: '🎭' },
    { id: 'playground', label: 'Playground', ico: '🧪' },
    { id: 'conversations', label: 'Conversations', ico: '💬' },
    { id: 'leads', label: 'Leads', ico: '📥' },
    { id: 'handoff', label: 'Handoff', ico: '🙋' },
    { id: 'analytics', label: 'Analytics', ico: '📈' },
    { id: 'embed', label: 'Embed', ico: '🧩' },
    { id: 'settings', label: 'Settings', ico: '⚙️' },
  ];

  async function route() {
    const r = parseRoute();
    state.route = r;

    if (!state.token) {
      const ok = await ensureGuest();
      if (!ok) return renderFatal('Could not start a session. Check that the preview is still running.');
    }
    if (!state.user) {
      const ok = await boot();
      if (!ok) return renderFatal('Could not load your account.');
    }

    renderShell();
    switch (r.view) {
      case 'overview': return renderOverview();
      case 'plans': return renderPlans();
      case 'api': return renderApi();
      case 'account': return renderAccount();
      case 'bot': {
        const bot = await loadBot(r.botId);
        if (!bot) { toast('Chatbot not found', 'err'); location.hash = '#/'; return; }
        renderBotTopbar();
        return renderBotTab(r.tab);
      }
      default: return renderOverview();
    }
  }

  // ---------------- shell ----------------
  function renderShell() {
    const root = $('#app');
    if (!$('.app', root)) {
      root.innerHTML =
        '<div class="app">' +
        '  <aside class="sidebar" id="sidebar">' + sidebarHtml() + '</aside>' +
        '  <div class="main">' +
        '    <header class="topbar" id="topbar">' + topbarHtml() + '</header>' +
        '    <div class="content" id="content"></div>' +
        '  </div>' +
        '</div>';
      wireShell();
    } else {
      $('#sidebar').innerHTML = sidebarHtml();
      $('#topbar').innerHTML = topbarHtml();
      wireShell();
    }
  }

  function sidebarHtml() {
    const r = state.route;
    const inBot = r && r.view === 'bot';
    const bot = state.bot;
    let html = '';
    html += '<div class="side-brand"><img src="/assets/logo.svg" alt="">Core AI</div>';
    html += '<nav class="side-nav">';

    if (inBot && bot) {
      html += '<div class="side-label">' + esc(bot.name) + '</div>';
      for (const t of BOT_TABS) {
        const active = r.tab === t.id ? ' active' : '';
        const badge = t.id === 'handoff' && bot._handoffs ? '<span class="badge">' + bot._handoffs + '</span>' : '';
        html += '<button class="side-item' + active + '" data-nav="#/b/' + bot.id + '/' + t.id + '"><span class="ico">' + t.ico + '</span>' + t.label + badge + '</button>';
      }
      html += '<div class="side-label">Workspace</div>';
    }
    html += '<button class="side-item" id="toStudio"><span class="ico">⚡</span>Workflow Studio</button>';
    html += '<button class="side-item' + (r.view === 'overview' ? ' active' : '') + '" data-nav="#/"><span class="ico">🤖</span>All chatbots</button>';
    html += '<button class="side-item' + (r.view === 'plans' ? ' active' : '') + '" data-nav="#/plans"><span class="ico">💳</span>Plans &amp; Billing</button>';
    html += '<button class="side-item' + (r.view === 'api' ? ' active' : '') + '" data-nav="#/api"><span class="ico">🔗</span>API &amp; Integrations</button>';
    html += '<button class="side-item' + (r.view === 'account' ? ' active' : '') + '" data-nav="#/account"><span class="ico">👤</span>Account</button>';
    html += '</nav>';
    html += '<div class="side-foot"><div class="user-chip"><span class="ava">' + esc(initials(state.user ? state.user.name : '')) + '</span>' +
      '<div><div class="nm">' + esc(state.user ? state.user.name : '') + '</div><div class="em">' + esc(state.user ? state.user.email : '') + '</div></div>' +
      '<button class="out" id="logoutBtn" title="Log out">⏻</button></div></div>';
    return html;
  }

  function topbarHtml() {
    const r = state.route;
    const inBot = r && r.view === 'bot' && state.bot;
    let html = '<button class="burger" id="burger">☰</button>';
    if (inBot) {
      const opts = state.chatbots.map((b) => '<option value="' + b.id + '"' + (b.id === state.bot.id ? ' selected' : '') + '>' + esc(b.name) + '</option>').join('');
      const live = state.bot.training.chunksCount > 0 && state.bot.enabled !== false;
      html += '<div class="bot-switch"><select class="select" id="botSwitcher" style="padding:9px 38px 9px 12px;font-size:14px">' + opts + '</select></div>';
      html += '<span class="bot-status ' + (live ? 'live' : 'draft') + '"><span class="dot"></span>' + (live ? 'Live' : 'Draft') + '</span>';
    } else {
      html += '<div style="font-weight:700;font-size:16px">Workspace</div>';
    }
    html += '<div class="spacer"></div><div class="tb-actions">';
    if (inBot) {
      html += '<button class="btn btn-light btn-sm" id="tbPreview">🧪 Test</button>';
      html += '<a class="btn btn-primary btn-sm" href="#/b/' + state.bot.id + '/embed">🧩 Embed</a>';
    } else {
      html += '<button class="btn btn-primary btn-sm" id="tbNewBot">＋ New chatbot</button>';
    }
    html += '</div>';
    return html;
  }

  function wireShell() {
    $$('#sidebar .side-item').forEach((b) => b.addEventListener('click', () => { location.hash = b.dataset.nav; closeSidebar(); }));
    const toStudio = $('#toStudio');
    if (toStudio) toStudio.addEventListener('click', () => { location.href = '/studio.html'; });
    const logout = $('#logoutBtn');
    if (logout) logout.addEventListener('click', doLogout);
    const burger = $('#burger');
    if (burger) burger.addEventListener('click', () => $('#sidebar').classList.add('open') && $('#backdrop').classList.add('show'));
    const backdrop = $('#backdrop');
    if (backdrop) backdrop.addEventListener('click', closeSidebar);
    const sw = $('#botSwitcher');
    if (sw) sw.addEventListener('change', () => { location.hash = '#/b/' + sw.value + '/overview'; });
    const newBot = $('#tbNewBot');
    if (newBot) newBot.addEventListener('click', createBotModal);
    const prev = $('#tbPreview');
    if (prev) prev.addEventListener('click', () => { location.hash = '#/b/' + state.bot.id + '/playground'; });
  }

  function closeSidebar() { const s = $('#sidebar'); if (s) s.classList.remove('open'); const b = $('#backdrop'); if (b) b.classList.remove('show'); }

  async function doLogout() {
    await api('/auth/logout', { method: 'POST' });
    clearSession();
    state.user = null; state.bot = null; state.chatbots = [];
    location.href = '/';
  }

  function renderBotTopbar() {
    const t = $('#topbar');
    if (t) t.innerHTML = topbarHtml();
    const s = $('#sidebar');
    if (s) s.innerHTML = sidebarHtml();
    wireShell();
  }

  // ---------------- guest session (no sign-in required) ----------------
  function guestId() {
    try {
      let g = localStorage.getItem('coreai_guest_id');
      if (!g) {
        g = 'g_' + Math.random().toString(36).slice(2, 10) + Date.now().toString(36);
        localStorage.setItem('coreai_guest_id', g);
      }
      return g;
    } catch (e) { return 'g_' + Math.random().toString(36).slice(2, 10) + Date.now().toString(36); }
  }

  // Auto-provision (or resume) a guest workspace — no credentials needed.
  async function ensureGuest() {
    let r = await api('/auth/guest', { method: 'POST', body: { guestId: guestId() } });
    if (r.status !== 200) {
      // one retry for a transient blip
      r = await api('/auth/guest', { method: 'POST', body: { guestId: guestId() } });
    }
    if (r.status !== 200 || !r.data.token) return false;
    setSession(r.data.token);
    return true;
  }

  function renderFatal(msg) {
    const root = $('#app');
    if (!root) return;
    root.innerHTML =
      '<div class="auth-wrap"><div class="auth-card">' +
      '  <div class="auth-brand"><img src="/assets/logo.svg" width="34" height="34" alt="">Core AI</div>' +
      '  <h1>Something went wrong</h1>' +
      '  <p class="sub">' + esc(msg || 'Could not start a session.') + '</p>' +
      '  <a class="btn btn-primary btn-block btn-lg" href="/studio.html">Open studio</a>' +
      '</div></div>';
  }

  // ---------------- overview ----------------
  async function renderOverview() {
    // refresh bot stats including handoff counts
    const hc = await api('/chatbots');
    if (hc.status === 200) state.chatbots = hc.data.chatbots;
    for (const b of state.chatbots) {
      const ac = await api('/chatbots/' + b.id + '/analytics');
      b._handoffs = ac.data && ac.data.analytics ? ac.data.analytics.totals.escalated - ac.data.analytics.totals.resolved : 0;
      b._handoffs = Math.max(0, b._handoffs);
    }
    const c = $('#content');
    let totalConvs = 0, totalMsgs = 0, totalLeads = 0;
    state.chatbots.forEach((b) => { totalConvs += b.stats.conversations; totalMsgs += b.stats.messages; totalLeads += b.stats.leads; });

    c.innerHTML =
      '<div class="page-head"><div><h1>Chatbots</h1><p>Build, train, and deploy AI support assistants.</p></div>' +
      '<button class="btn btn-primary" id="newBot">＋ New chatbot</button></div>' +
      '<div class="ov-grid">' +
      statCard('🤖', state.chatbots.length, 'chatbots', 'across your workspace') +
      statCard('💬', totalConvs, 'conversations', 'all time') +
      statCard('✉️', totalMsgs, 'messages handled', 'all time') +
      statCard('📥', totalLeads, 'leads captured', 'all time') +
      '</div>' +
      (state.chatbots.length
        ? '<div class="bot-cards">' + state.chatbots.map(botCardHtml).join('') + '</div>'
        : emptyState('🤖', 'No chatbots yet', 'Create your first AI chatbot and start answering customers instantly.', 'Create chatbot', 'newBotEmpty'));

    const nb = $('#newBot'); if (nb) nb.addEventListener('click', createBotModal);
    const nb2 = $('#newBotEmpty'); if (nb2) nb2.addEventListener('click', createBotModal);
    $$('.bot-card').forEach((card) => {
      const id = card.dataset.id;
      $('.open', card).addEventListener('click', () => { location.hash = '#/b/' + id + '/overview'; });
      $('.test', card).addEventListener('click', () => { location.hash = '#/b/' + id + '/playground'; });
      $('.embed', card).addEventListener('click', () => { location.hash = '#/b/' + id + '/embed'; });
      $('.del', card).addEventListener('click', () => deleteBot(id, card));
    });
  }

  function statCard(ico, v, k, s) {
    return '<div class="stat-card"><div class="k"><span>' + ico + '</span>' + k + '</div><div class="v">' + v + '</div><div class="s">' + s + '</div></div>';
  }

  function botCardHtml(b) {
    const live = b.training.chunksCount > 0;
    return '<div class="bot-card" data-id="' + b.id + '">' +
      '<div class="head"><span class="logo" style="background:linear-gradient(135deg,' + esc(b.primaryColor) + ',' + esc(b.primaryColor) + 'cc)">' + esc(b.logo) + '</span>' +
      '<div><div class="nm">' + esc(b.name) + '</div><div class="sub">' + b.stats.sources + ' sources · ' + b.stats.chunks + ' chunks</div></div>' +
      '<span class="pill ' + (live ? 'pill-ok' : 'pill-warn') + '" style="margin-left:auto">' + (live ? 'Live' : 'Draft') + '</span></div>' +
      '<div class="mini-stats"><span><b>' + b.stats.conversations + '</b> convos</span><span><b>' + b.stats.messages + '</b> messages</span><span><b>' + b.stats.leads + '</b> leads</span></div>' +
      '<div class="actions">' +
      '<button class="btn btn-outline btn-sm open">Open</button>' +
      '<button class="btn btn-light btn-sm test">🧪 Test</button>' +
      '<button class="btn btn-light btn-sm embed">🧩 Embed</button>' +
      '<button class="icon-btn danger del" title="Delete">🗑</button>' +
      '</div></div>';
  }

  function emptyState(ico, title, sub, cta, ctaId) {
    return '<div class="card empty"><div class="big">' + ico + '</div><h3>' + title + '</h3><p>' + sub + '</p>' +
      (cta ? '<button class="btn btn-primary" id="' + ctaId + '">' + cta + '</button>' : '') + '</div>';
  }

  function createBotModal() {
    const m = modal(
      '<div class="card-pad"><h3 style="margin-top:0">Create a chatbot</h3>' +
      '<div class="field"><label>Chatbot name</label><input class="input" id="nbName" placeholder="Support Assistant" maxlength="60"></div>' +
      '<div class="row" style="justify-content:flex-end;gap:10px"><button class="btn btn-ghost" id="nbCancel">Cancel</button><button class="btn btn-primary" id="nbCreate">Create</button></div></div>'
    );
    const name = $('#nbName', m.content);
    name.focus();
    $('#nbCancel', m.content).addEventListener('click', m.close);
    $('#nbCreate', m.content).addEventListener('click', async () => {
      const nm = name.value.trim() || 'My Assistant';
      const r = await api('/chatbots', { method: 'POST', body: { name: nm } });
      if (r.status === 201) { m.close(); toast('Chatbot created'); location.hash = '#/b/' + r.data.chatbot.id + '/training'; }
      else toast(r.data.error || 'Failed', 'err');
    });
  }

  async function deleteBot(id, cardEl) {
    const b = state.chatbots.find((x) => x.id === id);
    const m = modal('<div class="card-pad"><h3 style="margin-top:0">Delete “' + esc(b ? b.name : '') + '”?</h3>' +
      '<p class="muted">This permanently removes the chatbot, its training data, conversations, and leads.</p>' +
      '<div class="row" style="justify-content:flex-end;gap:10px"><button class="btn btn-ghost" id="dCancel">Cancel</button><button class="btn btn-danger" id="dConfirm">Delete</button></div></div>');
    $('#dCancel', m.content).addEventListener('click', m.close);
    $('#dConfirm', m.content).addEventListener('click', async () => {
      const r = await api('/chatbots/' + id, { method: 'DELETE' });
      if (r.status === 200) { m.close(); toast('Chatbot deleted'); route(); }
      else toast(r.data.error || 'Failed', 'err');
    });
  }

  // ---------------- bot tabs ----------------
  function renderBotTab(tab) {
    if (!BOT_TABS.some((t) => t.id === tab)) tab = 'overview';
    const c = $('#content');
    // render tab strip
    const strip = '<div class="tabs">' + BOT_TABS.map((t) => '<button class="tab' + (t.id === tab ? ' active' : '') + '" data-tab="' + t.id + '">' + t.label + '</button>').join('') + '</div>';
    c.innerHTML = strip + '<div id="tabContent"></div>';
    $$('.tab').forEach((b) => b.addEventListener('click', () => { location.hash = '#/b/' + state.bot.id + '/' + b.dataset.tab; }));
    const tc = $('#tabContent');
    switch (tab) {
      case 'overview': return renderBotOverview(tc);
      case 'training': return renderTraining(tc);
      case 'appearance': return renderAppearance(tc);
      case 'personality': return renderPersonality(tc);
      case 'playground': return renderPlayground(tc);
      case 'conversations': return renderConversations(tc);
      case 'leads': return renderLeads(tc);
      case 'handoff': return renderHandoff(tc);
      case 'analytics': return renderAnalytics(tc);
      case 'embed': return renderEmbed(tc);
      case 'settings': return renderSettings(tc);
    }
  }

  // ---- bot overview ----
  async function renderBotOverview(c) {
    const b = state.bot;
    const r = await api('/chatbots/' + b.id + '/analytics');
    const a = r.data.analytics || { totals: {}, recent: [] };
    const live = b.training.chunksCount > 0;
    c.innerHTML =
      '<div class="page-head"><div><h1>' + esc(b.name) + '</h1><p>Created ' + fmtDate(b.createdAt) + ' · ' + b.training.sourcesCount + ' sources · ' + b.training.chunksCount + ' knowledge chunks</p></div>' +
      '<div class="row wrap">' +
      (live ? '<button class="btn btn-light" id="ovTest">🧪 Test in playground</button>' : '<a class="btn btn-primary" href="#/b/' + b.id + '/training">🧠 Add training data</a>') +
      '<a class="btn btn-primary" href="#/b/' + b.id + '/embed">🧩 Get embed code</a></div></div>' +
      (live ? '' : '<div class="panel" style="background:var(--warn-soft);border-color:#fde68a"><div class="panel-body">⚠️ <b>This chatbot has no training data yet.</b> Add a URL, files, or text in the Training tab so it can answer questions.</div></div>') +
      '<div class="ov-grid">' +
      statCard('💬', a.totals.conversations || 0, 'conversations') +
      statCard('✉️', a.totals.messages || 0, 'messages') +
      statCard('📥', a.totals.leads || 0, 'leads') +
      statCard('🙋', a.totals.escalated || 0, 'handoffs') +
      '</div>' +
      '<div class="two-col">' +
      '<div class="panel"><div class="panel-head"><h3>Recent conversations</h3><a class="link small" href="#/b/' + b.id + '/conversations">View all</a></div><div class="panel-body" style="padding:0">' +
      (a.recent.length ? '<table class="table">' + a.recent.map((cc) => '<tr class="clickable" data-conv="' + cc.id + '"><td>' + esc(cc.visitorEmail || 'Visitor') + '</td><td class="muted">' + esc(cc.lastPreview) + '</td><td class="muted small">' + ago(cc.lastMessageAt) + '</td></tr>').join('') + '</table>' : '<p class="muted small" style="padding:20px">No conversations yet.</p>') +
      '</div></div>' +
      '<div class="panel"><div class="panel-head"><h3>Quick actions</h3></div><div class="panel-body" style="display:flex;flex-direction:column;gap:10px">' +
      '<a class="btn btn-outline btn-block" href="#/b/' + b.id + '/training">🧠 Add / refresh training</a>' +
      '<a class="btn btn-outline btn-block" href="#/b/' + b.id + '/appearance">🎨 Customize appearance</a>' +
      '<a class="btn btn-outline btn-block" href="#/b/' + b.id + '/analytics">📈 View analytics</a>' +
      '<a class="btn btn-outline btn-block" href="#/b/' + b.id + '/leads">📥 Export leads</a>' +
      '</div></div>' +
      '</div>';
    const t = $('#ovTest', c); if (t) t.addEventListener('click', () => location.hash = '#/b/' + b.id + '/playground');
    $$('tr[data-conv]', c).forEach((tr) => tr.addEventListener('click', () => { location.hash = '#/b/' + b.id + '/conversations?conv=' + tr.dataset.conv; }));
  }

  // ---- training ----
  let trainingPoll = null;
  async function renderTraining(c) {
    const b = state.bot;
    c.innerHTML =
      '<div class="page-head"><div><h1>Training</h1><p>Give your chatbot knowledge from a website, files, or plain text.</p></div>' +
      '<button class="btn btn-light" id="retrainBtn">↻ Retrain</button></div>' +
      '<div class="panel"><div class="panel-head"><h3>Add training data</h3></div><div class="panel-body">' +
      '<div class="tabs" id="srcTabs" style="margin-bottom:18px">' +
      '<button class="tab active" data-src="url">🌐 Website URL</button>' +
      '<button class="tab" data-src="file">📄 Upload files</button>' +
      '<button class="tab" data-src="text">📝 Paste text</button></div>' +
      '<div id="srcPane"></div>' +
      '</div></div>' +
      '<div id="sourcesList"></div>' +
      '<div class="panel"><div class="panel-head"><h3>Q&amp;A pairs</h3><p>Exact questions and the answers you want your bot to give.</p></div>' +
      '<div class="panel-body"><div id="qnaList"></div>' +
      '<form id="qnaForm" class="form-grid mt-2" style="border-top:1px solid var(--line);padding-top:18px">' +
      '<div class="field mb-0"><label>Question</label><input class="input" id="qnaQ" placeholder="What are your business hours?"></div>' +
      '<div class="field mb-0"><label>Answer</label><input class="input" id="qnaA" placeholder="We are open 9–6, Mon–Fri."></div>' +
      '<div class="form-full"><button class="btn btn-outline btn-sm" type="submit">＋ Add Q&amp;A</button></div></form></div></div>';

    showSrcPane('url');
    $('#srcTabs', c).addEventListener('click', (e) => {
      const btn = e.target.closest('.tab'); if (!btn) return;
      $$('#srcTabs .tab', c).forEach((x) => x.classList.remove('active'));
      btn.classList.add('active');
      showSrcPane(btn.dataset.src);
    });
    $('#retrainBtn', c).addEventListener('click', async () => {
      $('#retrainBtn').innerHTML = '<span class="spinner dark"></span> Retraining…';
      const r = await api('/chatbots/' + b.id + '/retrain', { method: 'POST' });
      $('#retrainBtn').innerHTML = '↻ Retrain';
      toast(r.status === 200 ? 'Knowledge index rebuilt' : (r.data.error || 'Failed'), r.status === 200 ? 'ok' : 'err');
      loadBot(b.id);
      renderSources();
    });
    const qf = $('#qnaForm', c);
    qf.addEventListener('submit', async (e) => {
      e.preventDefault();
      const q = $('#qnaQ').value.trim(), a = $('#qnaA').value.trim();
      if (!q || !a) return toast('Both fields are required', 'err');
      const r = await api('/chatbots/' + b.id + '/qna', { method: 'POST', body: { question: q, answer: a } });
      if (r.status === 201) { $('#qnaQ').value = ''; $('#qnaA').value = ''; renderQna(); }
      else toast(r.data.error || 'Failed', 'err');
    });
    renderSources();
    renderQna();
    startTrainingPoll(c);
  }

  function showSrcPane(kind) {
    const pane = $('#srcPane');
    if (kind === 'url') {
      pane.innerHTML = '<div class="field"><label>Website URL</label><input class="input" id="urlInput" placeholder="https://example.com"></div>' +
        '<div class="field"><label>Pages to scan</label><select class="select" id="urlPages"><option value="1">Just this page</option><option value="3" selected>Up to 3 pages</option><option value="6">Up to 6 pages</option></select></div>' +
        '<button class="btn btn-primary" id="urlGo">🌐 Train from URL</button>';
      $('#urlGo').addEventListener('click', async () => {
        const url = $('#urlInput').value.trim();
        if (!/^https?:\/\//i.test(url)) return toast('Enter a valid URL', 'err');
        const btn = $('#urlGo'); btn.disabled = true; btn.innerHTML = '<span class="spinner"></span> Crawling…';
        const r = await api('/chatbots/' + state.bot.id + '/sources/url', { method: 'POST', body: { url, maxPages: parseInt($('#urlPages').value, 10) } });
        btn.disabled = false; btn.innerHTML = '🌐 Train from URL';
        if (r.status === 202) { toast('Training started — scanning pages…'); renderSources(); startTrainingPoll(); }
        else toast(r.data.error || 'Failed', 'err');
      });
    } else if (kind === 'file') {
      pane.innerHTML = '<div class="field"><label>Upload files</label><input type="file" id="fileInput" multiple accept=".txt,.md,.markdown,.csv,.html,.htm,.json,.xml,.yaml,.yml,.pdf" class="input">' +
        '<div class="hint">Supported: TXT, MD, CSV, HTML, JSON, XML, YAML, and text-based PDFs. Office files — please paste as text.</div>' +
        '<button class="btn btn-primary mt-2" id="fileGo" disabled>📄 Upload</button>';
      $('#fileInput').addEventListener('change', () => { $('#fileGo').disabled = !$('#fileInput').files.length; });
      $('#fileGo').addEventListener('click', async () => {
        const files = Array.from($('#fileInput').files);
        if (!files.length) return;
        for (const f of files) {
          const buf = await f.arrayBuffer();
          const b64 = btoa(String.fromCharCode.apply(null, new Uint8Array(buf)));
          const r = await api('/chatbots/' + state.bot.id + '/sources/file', { method: 'POST', body: { filename: f.name, mimeType: f.type, dataBase64: b64 } });
          if (r.status === 201) toast('Uploaded: ' + f.name, 'ok');
          else toast(f.name + ': ' + (r.data.error || 'failed'), 'err');
        }
        renderSources();
        loadBot(state.bot.id);
      });
    } else {
      pane.innerHTML = '<div class="field"><label>Title</label><input class="input" id="textTitle" placeholder="e.g. Company policies"></div>' +
        '<div class="field"><label>Content</label><textarea class="textarea" id="textContent" style="min-height:150px" placeholder="Paste your content here…"></textarea></div>' +
        '<button class="btn btn-primary" id="textGo">📝 Add text</button>';
      $('#textGo').addEventListener('click', async () => {
        const title = $('#textTitle').value.trim() || 'Pasted text';
        const content = $('#textContent').value;
        if (content.trim().length < 20) return toast('Please paste some content first', 'err');
        const r = await api('/chatbots/' + state.bot.id + '/sources/text', { method: 'POST', body: { title, content } });
        if (r.status === 201) { toast('Text added & indexed', 'ok'); renderSources(); loadBot(state.bot.id); }
        else toast(r.data.error || 'Failed', 'err');
      });
    }
  }

  async function renderSources() {
    const list = $('#sourcesList');
    if (!list) return;
    const r = await api('/chatbots/' + state.bot.id + '/sources');
    const sources = r.data.sources || [];
    const fetching = sources.some((s) => s.status === 'fetching');
    list.innerHTML =
      '<div class="panel"><div class="panel-head"><h3>Knowledge sources</h3><span class="pill">' + sources.length + ' sources · ' + sources.reduce((a, s) => a + s.chunks, 0) + ' chunks</span></div>' +
      '<div class="panel-body" style="padding:0">' +
      (sources.length
        ? '<table class="table"><thead><tr><th>Title</th><th>Type</th><th>Size</th><th>Chunks</th><th>Status</th><th>Updated</th><th></th></tr></thead><tbody>' +
          sources.map((s) => '<tr>' +
            '<td style="max-width:320px"><div style="font-weight:600">' + esc(s.title) + '</div>' + (s.url ? '<div class="small muted mono">' + esc(s.url.slice(0, 60)) + '</div>' : '') + '</td>' +
            '<td><span class="pill">' + (s.type === 'url' ? '🌐 URL' : s.type === 'file' ? '📄 File' : '📝 Text') + '</span></td>' +
            '<td class="muted">' + Math.round(s.chars / 1024) + ' KB</td>' +
            '<td class="muted">' + s.chunks + '</td>' +
            '<td>' + sourceStatus(s) + '</td>' +
            '<td class="muted small">' + ago(s.refreshedAt) + '</td>' +
            '<td><div class="row-actions">' + (s.type === 'url' ? '<button class="icon-btn" title="Refresh" data-refresh="' + s.id + '">↻</button>' : '') + '<button class="icon-btn danger" title="Delete" data-del="' + s.id + '">🗑</button></div></td>' +
            '</tr>').join('') + '</tbody></table>'
        : '<p class="muted" style="padding:22px">No sources yet. Add your website, files, or text above.</p>') +
      '</div></div>';
    $$('button[data-refresh]', list).forEach((btn) => btn.addEventListener('click', async () => {
      const r = await api('/chatbots/' + state.bot.id + '/sources/' + btn.dataset.refresh + '/refresh', { method: 'POST' });
      toast('Refreshing…');
      renderSources(); startTrainingPoll();
    }));
    $$('button[data-del]', list).forEach((btn) => btn.addEventListener('click', async () => {
      const r = await api('/chatbots/' + state.bot.id + '/sources/' + btn.dataset.del, { method: 'DELETE' });
      if (r.status === 200) { toast('Source removed', 'ok'); renderSources(); loadBot(state.bot.id); }
    }));
    if (fetching) startTrainingPoll();
  }

  function sourceStatus(s) {
    if (s.status === 'ready') return '<span class="pill pill-ok">Ready</span>';
    if (s.status === 'fetching') return '<span class="pill pill-warn"><span class="spinner dark" style="width:12px;height:12px;border-width:2px"></span> Scanning…</span>';
    if (s.status === 'empty') return '<span class="pill pill-warn">No text found</span>';
    return '<span class="pill pill-danger" title="' + esc(s.error || '') + '">Error</span>';
  }

  function startTrainingPoll(c) {
    if (trainingPoll) clearInterval(trainingPoll);
    trainingPoll = setInterval(async () => {
      const r = await api('/chatbots/' + state.bot.id + '/sources');
      const fetching = (r.data.sources || []).some((s) => s.status === 'fetching');
      renderSources();
      loadBot(state.bot.id);
      if (!fetching) { clearInterval(trainingPoll); trainingPoll = null; renderBotTopbar(); }
    }, 2000);
  }

  async function renderQna() {
    const list = $('#qnaList');
    if (!list) return;
    const r = await api('/chatbots/' + state.bot.id + '/qna');
    const qna = r.data.qna || [];
    list.innerHTML = qna.length
      ? '<table class="table"><tbody>' + qna.map((q) => '<tr><td><div style="font-weight:600">' + esc(q.question) + '</div><div class="muted small">' + esc(q.answer) + '</div></td><td style="width:50px"><button class="icon-btn danger" data-qdel="' + q.id + '">🗑</button></td></tr>').join('') + '</tbody></table>'
      : '<p class="muted small mb-2">No Q&amp;A pairs yet. Add exact answers below — they take priority over retrieved content.</p>';
    $$('button[data-qdel]', list).forEach((btn) => btn.addEventListener('click', async () => {
      await api('/chatbots/' + state.bot.id + '/qna/' + btn.dataset.qdel, { method: 'DELETE' });
      renderQna();
    }));
  }

  // ---- appearance ----
  function renderAppearance(c) {
    const b = state.bot;
    c.innerHTML =
      '<div class="page-head"><div><h1>Appearance</h1><p>Match the chatbot to your brand.</p></div><button class="btn btn-primary" id="saveApp">💾 Save changes</button></div>' +
      '<div class="two-col"><div>' +
      '<div class="panel"><div class="panel-body">' +
      '<div class="field"><label>Chatbot name</label><input class="input" id="appName" value="' + esc(b.name) + '" maxlength="60"></div>' +
      '<div class="field"><label>Welcome message</label><textarea class="textarea" id="appWelcome" style="min-height:90px">' + esc(b.welcomeMessage) + '</textarea></div>' +
      '<div class="field"><label>Placeholder text</label><input class="input" id="appPlaceholder" value="' + esc(b.placeholder) + '"></div>' +
      '<div class="field"><label>Logo</label><div class="chips">' + LOGOS.map((l) => '<button class="chip logo-chip' + (b.logo === l ? ' sel' : '') + '" data-logo="' + l + '">' + l + '</button>').join('') + '</div>' +
      '<div class="hint">Pick an emoji logo — custom image upload is on the roadmap.</div></div>' +
      '<div class="field"><label>Brand color</label><div class="color-inputs">' +
      SWATCHES.map((s) => '<div class="swatch' + (b.primaryColor === s ? ' sel' : '') + '" data-color="' + s + '" style="background:' + s + '"></div>').join('') +
      '<div class="color-custom"><input type="color" id="appColor" value="' + esc(b.primaryColor) + '"><span class="small muted">Custom</span></div></div></div>' +
      '<div class="field"><label>Widget position</label><select class="select" id="appPos"><option value="bottom-right"' + (b.position === 'bottom-right' ? ' selected' : '') + '>Bottom right</option><option value="bottom-left"' + (b.position === 'bottom-left' ? ' selected' : '') + '>Bottom left</option></select></div>' +
      '</div></div>' +
      '</div><div>' +
      '<div class="panel" style="position:sticky;top:84px"><div class="panel-head"><h3>Live preview</h3></div><div class="panel-body" style="background:var(--bg-soft)">' + appearancePreview(b) + '</div></div>' +
      '</div></div>';

    $$('.swatch', c).forEach((el) => el.addEventListener('click', () => {
      $$('.swatch', c).forEach((x) => x.classList.remove('sel'));
      el.classList.add('sel');
      $('#appColor').value = el.dataset.color;
      refreshPreview();
    }));
    $$('.logo-chip', c).forEach((el) => el.addEventListener('click', () => {
      $$('.logo-chip', c).forEach((x) => x.classList.remove('sel'));
      el.classList.add('sel');
      refreshPreview();
    }));
    $('#appColor', c).addEventListener('input', refreshPreview);
    ['appName', 'appWelcome', 'appPlaceholder'].forEach((id) => $('#' + id, c).addEventListener('input', refreshPreview));

    $('#saveApp', c).addEventListener('click', async () => {
      const logo = ($('.logo-chip.sel', c) || {}).dataset ? $('.logo-chip.sel', c).dataset.logo : b.logo;
      const body = {
        name: $('#appName').value.trim(),
        welcomeMessage: $('#appWelcome').value.trim(),
        placeholder: $('#appPlaceholder').value.trim(),
        logo: logo || b.logo,
        primaryColor: $('#appColor').value,
        position: $('#appPos').value,
      };
      const r = await api('/chatbots/' + b.id, { method: 'PATCH', body });
      if (r.status === 200) { state.bot = r.data.chatbot; toast('Saved', 'ok'); renderBotTopbar(); }
      else toast(r.data.error || 'Failed', 'err');
    });

    function refreshPreview() {
      const name = $('#appName').value || 'Assistant';
      const color = $('#appColor').value || '#6366f1';
      const logo = ($('.logo-chip.sel', c) || { dataset: { logo: b.logo } }).dataset.logo;
      const welcome = $('#appWelcome').value || '';
      const prev = $('.prev-card', c);
      if (!prev) return;
      $('.prev-avatar', prev).style.background = 'linear-gradient(135deg,' + color + ',' + color + 'cc)';
      $('.prev-avatar', prev).textContent = logo;
      $('.prev-title', prev).textContent = name;
      $('.prev-welcome', prev).textContent = welcome || 'Hi! Ask me anything.';
      prev.style.setProperty('--c', color);
    }
  }

  function appearancePreview(b) {
    return '<div class="prev-card" style="--c:' + esc(b.primaryColor) + ';background:#fff;border:1px solid var(--line);border-radius:16px;overflow:hidden;box-shadow:var(--shadow)">' +
      '<div style="padding:13px 15px;display:flex;align-items:center;gap:10px;background:linear-gradient(135deg,' + esc(b.primaryColor) + ',' + esc(b.primaryColor) + 'cc);color:#fff">' +
      '<span class="prev-avatar" style="width:36px;height:36px;border-radius:10px;background:rgba(255,255,255,.2);display:flex;align-items:center;justify-content:center;font-size:18px">' + esc(b.logo) + '</span>' +
      '<div><div class="prev-title" style="font-weight:700;font-size:14px">' + esc(b.name) + '</div><div style="font-size:11.5px;opacity:.9">● Online — replies instantly</div></div></div>' +
      '<div style="padding:14px;display:flex;flex-direction:column;gap:8px;background:#f8f8ff;min-height:150px">' +
      '<div style="background:#fff;border:1px solid var(--line);border-radius:12px 12px 12px 4px;padding:9px 12px;font-size:13.5px;align-self:flex-start;max-width:85%"><span class="prev-welcome">' + esc(b.welcomeMessage) + '</span></div>' +
      '<div style="background:var(--c);color:#fff;border-radius:12px 12px 4px 12px;padding:9px 12px;font-size:13.5px;align-self:flex-end;max-width:85%">Do you have a free trial?</div>' +
      '<div style="background:#fff;border:1px solid var(--line);border-radius:12px 12px 12px 4px;padding:9px 12px;font-size:13.5px;align-self:flex-start;max-width:85%">Yes — 7 days free, no credit card. 🙌</div>' +
      '</div>' +
      '<div style="padding:10px;border-top:1px solid var(--line);font-size:12px;color:var(--ink-400);display:flex;justify-content:space-between"><span>' + esc(b.placeholder || 'Type your question…') + '</span><span style="background:var(--c);color:#fff;width:24px;height:24px;border-radius:8px;display:inline-flex;align-items:center;justify-content:center">➤</span></div>' +
      '<div style="text-align:center;font-size:10.5px;color:var(--ink-300);padding:5px">Powered by <b>Core AI</b></div></div>';
  }

  // ---- personality ----
  function renderPersonality(c) {
    const b = state.bot;
    c.innerHTML =
      '<div class="page-head"><div><h1>Personality</h1><p>Shape how your chatbot talks and behaves.</p></div><button class="btn btn-primary" id="savePers">💾 Save</button></div>' +
      '<div class="panel"><div class="panel-body">' +
      '<div class="field"><label>System prompt / instructions</label><textarea class="textarea" id="persPrompt" style="min-height:150px">' + esc(b.personality) + '</textarea>' +
      '<div class="hint">Tells the bot how to behave: tone, language, and what to do when it doesn\'t know an answer.</div></div>' +
      '<div class="field"><label>Answer style</label><select class="select" id="persModel">' +
      '<option value="concise"' + (b.model === 'concise' ? ' selected' : '') + '>Concise — short, punchy replies</option>' +
      '<option value="balanced"' + (b.model === 'balanced' ? ' selected' : '') + '>Balanced — helpful with a bit of detail</option>' +
      '<option value="detailed"' + (b.model === 'detailed' ? ' selected' : '') + '>Detailed — thorough, step-by-step answers</option>' +
      '</select></div>' +
      '</div></div>' +
      '<div class="panel"><div class="panel-head"><h3>Quick prompts</h3><p>Suggested questions shown to visitors when they open the chat.</p></div>' +
      '<div class="panel-body"><div class="chips" id="promptChips">' + (b.quickPrompts || []).map((q, i) => '<span class="chip">' + esc(q) + '<button data-rm="' + i + '">✕</button></span>').join('') + '</div>' +
      '<div class="row mt-2"><input class="input" id="promptInput" placeholder="Add a question…" style="max-width:360px"><button class="btn btn-outline btn-sm" id="promptAdd">＋ Add</button></div>' +
      '<div class="hint">Up to 6 prompts.</div></div></div>';

    const chips = [];
    (b.quickPrompts || []).forEach((q) => chips.push(q));
    const renderChips = () => {
      const w = $('#promptChips', c);
      w.innerHTML = chips.map((q, i) => '<span class="chip">' + esc(q) + '<button data-rm="' + i + '">✕</button></span>').join('');
      $$('button[data-rm]', w).forEach((btn) => btn.addEventListener('click', () => { chips.splice(parseInt(btn.dataset.rm, 10), 1); renderChips(); }));
    };
    $('#promptAdd', c).addEventListener('click', () => {
      const v = $('#promptInput').value.trim();
      if (!v) return;
      if (chips.length >= 6) return toast('Maximum 6 prompts', 'err');
      chips.push(v); $('#promptInput').value = ''; renderChips();
    });
    $('#savePers', c).addEventListener('click', async () => {
      const r = await api('/chatbots/' + b.id, { method: 'PATCH', body: { personality: $('#persPrompt').value.trim(), model: $('#persModel').value, quickPrompts: chips } });
      if (r.status === 200) { state.bot = r.data.chatbot; toast('Saved', 'ok'); }
      else toast(r.data.error || 'Failed', 'err');
    });
  }

  // ---- playground ----
  async function renderPlayground(c) {
    const b = state.bot;
    const live = b.training.chunksCount > 0;
    c.innerHTML =
      '<div class="page-head"><div><h1>Playground</h1><p>Test your chatbot exactly as visitors experience it.</p></div>' +
      '<button class="btn btn-light" id="pgClear">🗑 Clear</button></div>' +
      (live ? '' : '<div class="panel" style="background:var(--warn-soft);border-color:#fde68a"><div class="panel-body">⚠️ <b>No training data yet.</b> The bot can only fall back and hand off. <a class="link" href="#/b/' + b.id + '/training">Add training data →</a></div></div>') +
      '<div class="chat-wrap"><div class="chat-msgs" id="pgMsgs"></div>' +
      '<div class="chat-input-row"><textarea id="pgInput" rows="1" placeholder="Ask something your visitors would ask…"></textarea><button class="btn btn-primary" id="pgSend" style="padding:13px 20px">➤</button></div></div>';

    const msgs = $('#pgMsgs');
    const r = await api('/chatbots/' + b.id + '/playground');
    (r.data.messages || []).forEach((m) => appendMsg(msgs, m, true));

    function send() {
      const input = $('#pgInput');
      const text = input.value.trim();
      if (!text) return;
      input.value = ''; input.style.height = 'auto';
      appendMsg(msgs, { role: 'user', text, ts: new Date().toISOString() }, false);
      const t = appendTyping(msgs);
      api('/chatbots/' + b.id + '/playground', { method: 'POST', body: { message: text } }).then((resp) => {
        if (t.parentNode) t.parentNode.removeChild(t);
        if (resp.status === 200) appendMsg(msgs, { role: 'bot', text: resp.data.reply, ts: new Date().toISOString(), mode: resp.data.mode, sources: resp.data.sources }, false);
        else appendMsg(msgs, { role: 'bot', text: resp.data.error || 'Error', ts: new Date().toISOString() }, false);
      });
    }
    $('#pgSend').addEventListener('click', send);
    $('#pgInput').addEventListener('keydown', (e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); } });
    $('#pgClear').addEventListener('click', async () => { await api('/chatbots/' + b.id + '/playground', { method: 'DELETE' }); msgs.innerHTML = ''; });
  }

  function appendTyping(msgs) {
    const t = document.createElement('div');
    t.className = 'msg bot cw-typing';
    t.innerHTML = '<i></i><i></i><i></i>';
    msgs.appendChild(t);
    msgs.scrollTop = msgs.scrollHeight;
    return t;
  }

  function appendMsg(msgs, m, allowRate) {
    const d = document.createElement('div');
    const cls = m.role === 'user' ? 'user' : m.role === 'human' ? 'human' : m.role === 'system' ? 'system' : 'bot';
    d.className = 'msg ' + cls;
    let inner = '';
    if (m.role === 'human') inner += '<div style="font-size:11px;font-weight:700;opacity:.7;margin-bottom:3px">TEAM</div>';
    inner += esc(m.text);
    if (m.mode && m.role === 'bot') {
      const modeLabel = m.mode === 'llm' ? 'LLM' : m.mode === 'qa' ? 'Curated answer' : m.mode === 'retrieval' ? 'Retrieved' : m.mode === 'fallback' ? 'Fallback' : m.mode;
      inner += '<div class="m-meta"><span class="src-pill">' + modeLabel + '</span>' +
        (m.sources && m.sources.length ? '<span class="src-pill">📎 ' + esc(m.sources[0].title) + '</span>' : '') +
        '<span class="ts">' + fmtTime(m.ts) + '</span>' +
        '<span class="rate"><button data-r="up" class="' + (m.rating === 'up' ? 'on-up' : '') + '" title="Good answer">👍</button><button data-r="down" class="' + (m.rating === 'down' ? 'on-down' : '') + '" title="Bad answer">👎</button></span>' +
        '</div>';
    } else if (m.role !== 'system') {
      inner += '<div class="m-meta"><span class="ts">' + fmtTime(m.ts) + '</span></div>';
    }
    d.innerHTML = inner;
    msgs.appendChild(d);
    msgs.scrollTop = msgs.scrollHeight;
    if (allowRate) {
      $$('.rate button', d).forEach((btn) => btn.addEventListener('click', () => {
        $$('.rate button', d).forEach((x) => x.classList.remove('on-up', 'on-down'));
        if (m.rating === btn.dataset.r) { m.rating = null; } else { m.rating = btn.dataset.r; btn.classList.add(btn.dataset.r === 'up' ? 'on-up' : 'on-down'); }
        toast(m.rating ? 'Thanks — feedback saved' : 'Feedback cleared', 'ok');
      }));
    }
  }

  // ---- conversations ----
  async function renderConversations(c) {
    const b = state.bot;
    const url = new URLSearchParams(location.hash.split('?')[1] || '');
    const convParam = url.get('conv');
    const r = await api('/chatbots/' + b.id + '/conversations');
    const convs = r.data.conversations || [];

    if (convParam) return renderConversationDetail(c, convParam);

    c.innerHTML =
      '<div class="page-head"><div><h1>Conversations</h1><p>Review every chat and how your bot performed.</p></div></div>' +
      '<div class="panel"><div class="panel-body" style="padding:0">' +
      (convs.length
        ? '<table class="table"><thead><tr><th>Visitor</th><th>Last message</th><th>Msgs</th><th>When</th><th>Status</th><th></th></tr></thead><tbody>' +
        convs.map((cc) => '<tr class="clickable" data-conv="' + cc.id + '">' +
          '<td><div style="font-weight:600">' + esc(cc.visitorEmail || cc.visitorName || 'Anonymous visitor') + '</div><div class="small muted mono">' + esc(cc.visitorId.slice(0, 12)) + '</div></td>' +
          '<td class="muted" style="max-width:320px">' + esc(cc.lastPreview) + '</td>' +
          '<td class="muted">' + cc.messageCount + '</td>' +
          '<td class="muted small">' + ago(cc.lastMessageAt) + '</td>' +
          '<td>' + (cc.escalated ? '<span class="pill pill-warn">🙋 Escalated</span>' : cc.resolved ? '<span class="pill pill-ok">✓ Resolved</span>' : '<span class="pill">' + (cc.sample ? 'Sample' : 'Closed') + '</span>') + '</td>' +
          '<td><div class="row-actions"><button class="icon-btn" title="Open" data-conv="' + cc.id + '">→</button><button class="icon-btn danger" title="Delete" data-del="' + cc.id + '">🗑</button></div></td>' +
          '</tr>').join('') + '</tbody></table>'
        : emptyState('💬', 'No conversations yet', 'When visitors chat with your bot, the transcripts appear here.', '', '')) +
      '</div></div>';
    $$('tr[data-conv]', c).forEach((tr) => tr.addEventListener('click', () => { location.hash = '#/b/' + b.id + '/conversations?conv=' + tr.dataset.conv; }));
    $$('button[data-conv]', c).forEach((btn) => btn.addEventListener('click', (e) => { e.stopPropagation(); location.hash = '#/b/' + b.id + '/conversations?conv=' + btn.dataset.conv; }));
    $$('button[data-del]', c).forEach((btn) => btn.addEventListener('click', async (e) => {
      e.stopPropagation();
      const r = await api('/chatbots/' + b.id + '/conversations/' + btn.dataset.del, { method: 'DELETE' });
      if (r.status === 200) { toast('Conversation deleted', 'ok'); renderConversations(c); }
    }));
  }

  async function renderConversationDetail(c, convId) {
    const b = state.bot;
    const r = await api('/chatbots/' + b.id + '/conversations/' + convId);
    if (r.status !== 200) { c.innerHTML = '<p>Conversation not found.</p>'; return; }
    const conv = r.data.conversation;
    c.innerHTML =
      '<div class="page-head"><div><a class="link" href="#/b/' + b.id + '/conversations">← All conversations</a>' +
      '<h1 style="margin-top:6px">' + esc(conv.visitorEmail || conv.visitorName || 'Anonymous visitor') + '</h1>' +
      '<p>' + fmtTime(conv.startedAt) + ' · ' + conv.messages.length + ' messages' + (conv.sample ? ' · <span class="pill pill-warn">Sample data</span>' : '') + '</p></div>' +
      '<div class="row wrap">' + (conv.escalated ? '<button class="btn btn-outline btn-sm" id="cvResolve">✓ Mark resolved</button>' : '') +
      '<button class="btn btn-light btn-sm" id="cvDelete">🗑 Delete</button></div></div>' +
      '<div class="chat-wrap" style="height:460px"><div class="chat-msgs" id="cvMsgs"></div>' +
      (conv.escalated ? '<div class="chat-input-row" style="background:var(--ok-soft)"><textarea id="cvReply" rows="1" placeholder="Reply to this visitor as a human…"></textarea><button class="btn btn-primary" id="cvSend" style="padding:13px 20px">Send</button></div>' : '') +
      '</div>';
    const msgs = $('#cvMsgs');
    conv.messages.forEach((m, i) => {
      appendMsg(msgs, m, false);
      if (m.role === 'bot' && !m.rating) {
        const last = msgs.lastElementChild;
        const addQa = document.createElement('button');
        addQa.className = 'link small';
        addQa.style.cssText = 'background:none;border:none;font-size:11px;margin-top:6px';
        addQa.textContent = '＋ Add to Q&A';
        addQa.addEventListener('click', async () => {
          const prevUser = conv.messages.slice(0, i).reverse().find((x) => x.role === 'user');
          const q = prevUser ? prevUser.text : m.text.slice(0, 80);
          const rr = await api('/chatbots/' + b.id + '/qna', { method: 'POST', body: { question: q, answer: m.text } });
          if (rr.status === 201) { toast('Added to Q&A — takes priority in future answers', 'ok'); addQa.remove(); }
          else toast(rr.data.error || 'Failed', 'err');
        });
        last.appendChild(addQa);
      }
    });
    const res = $('#cvResolve'); if (res) res.addEventListener('click', async () => {
      await api('/chatbots/' + b.id + '/conversations/' + convId + '/resolve', { method: 'POST' });
      toast('Marked as resolved', 'ok'); renderConversationDetail(c, convId);
    });
    const del = $('#cvDelete'); if (del) del.addEventListener('click', async () => {
      await api('/chatbots/' + b.id + '/conversations/' + convId, { method: 'DELETE' });
      toast('Deleted', 'ok'); location.hash = '#/b/' + b.id + '/conversations';
    });
    const send = $('#cvSend'); if (send) {
      const doReply = async () => {
        const v = $('#cvReply').value.trim();
        if (!v) return;
        const rr = await api('/chatbots/' + b.id + '/conversations/' + convId + '/human-reply', { method: 'POST', body: { text: v } });
        if (rr.status === 200) { renderConversationDetail(c, convId); }
        else toast(rr.data.error || 'Failed', 'err');
      };
      send.addEventListener('click', doReply);
      $('#cvReply').addEventListener('keydown', (e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); doReply(); } });
    }
  }

  // ---- leads ----
  async function renderLeads(c) {
    const b = state.bot;
    const r = await api('/chatbots/' + b.id + '/leads');
    const leads = r.data.leads || [];
    c.innerHTML =
      '<div class="page-head"><div><h1>Leads</h1><p>Contact details captured by your chatbot.</p></div>' +
      '<button class="btn btn-primary" id="leadExport">⬇ Export CSV</button></div>' +
      '<div class="panel"><div class="panel-body" style="padding:0">' +
      (leads.length
        ? '<table class="table"><thead><tr><th>Email</th><th>Name</th><th>Phone</th><th>Source</th><th>Captured</th><th></th></tr></thead><tbody>' +
        leads.map((l) => '<tr><td style="font-weight:600">' + esc(l.email) + '</td><td>' + esc(l.name || '—') + '</td><td class="muted">' + esc(l.phone || '—') + '</td><td><span class="pill">💬 Chat widget</span></td><td class="muted small">' + fmtTime(l.capturedAt) + '</td><td><button class="icon-btn danger" data-del="' + l.id + '">🗑</button></td></tr>').join('') +
        '</tbody></table>'
        : emptyState('📥', 'No leads yet', 'Enable lead capture in the widget — visitors who share their email will appear here.', '', '')) +
      '</div></div>';
    $('#leadExport', c).addEventListener('click', async () => {
      const resp = await fetch('/api/chatbots/' + b.id + '/leads.csv', { headers: { Authorization: 'Bearer ' + state.token } });
      if (resp.ok) {
        const blob = await resp.blob();
        const a = document.createElement('a');
        a.href = URL.createObjectURL(blob);
        a.download = 'coreai-leads-' + b.id + '.csv';
        a.click();
        URL.revokeObjectURL(a.href);
      } else toast('Export failed', 'err');
    });
    $$('button[data-del]', c).forEach((btn) => btn.addEventListener('click', async () => {
      await api('/chatbots/' + b.id + '/leads/' + btn.dataset.del, { method: 'DELETE' });
      renderLeads(c);
    }));
  }

  // ---- handoff ----
  async function renderHandoff(c) {
    const b = state.bot;
    const r = await api('/chatbots/' + b.id + '/conversations');
    const queue = (r.data.conversations || []).filter((cc) => cc.escalated);
    c.innerHTML =
      '<div class="page-head"><div><h1>Handoff queue</h1><p>Visitors waiting for a human reply.</p></div></div>' +
      (queue.length
        ? '<div class="grid" style="grid-template-columns:repeat(auto-fill,minmax(340px,1fr))">' +
        queue.map((cc) => '<div class="card card-pad" data-conv="' + cc.id + '">' +
          '<div class="row-between"><div><div style="font-weight:700">' + esc(cc.visitorEmail || cc.visitorName || 'Anonymous visitor') + '</div><div class="small muted">' + ago(cc.lastMessageAt) + ' · ' + cc.messageCount + ' msgs</div></div>' +
          '<span class="pill pill-warn">Waiting</span></div>' +
          '<p class="muted small mt-2" style="background:var(--bg-soft);padding:10px 12px;border-radius:10px">“' + esc(cc.lastPreview) + '”</p>' +
          '<div class="row mt-2" style="gap:8px"><button class="btn btn-outline btn-sm" data-open="' + cc.id + '">Open &amp; reply</button></div>' +
          '</div>').join('') + '</div>'
        : emptyState('🙋', 'Queue is clear', 'When a visitor taps “Talk to a human”, the conversation shows up here for you to reply.', '', ''));
    $$('button[data-open]', c).forEach((btn) => btn.addEventListener('click', () => { location.hash = '#/b/' + b.id + '/conversations?conv=' + btn.dataset.open; }));
  }

  // ---- analytics ----
  async function renderAnalytics(c) {
    const b = state.bot;
    const r = await api('/chatbots/' + b.id + '/analytics');
    const a = r.data.analytics || { totals: {}, series: [], topSources: [], recent: [] };
    const t = a.totals;
    const escRate = t.conversations ? Math.round((t.escalated / t.conversations) * 100) : 0;
    const max = Math.max.apply(null, a.series.map((s) => s.messages).concat([1]));

    c.innerHTML =
      '<div class="page-head"><div><h1>Analytics</h1><p>Usage computed from your real conversations.</p></div>' +
      '<div class="row"><button class="btn btn-light btn-sm" id="loadSample">🎲 Load sample data</button>' +
      '<button class="btn btn-ghost btn-sm" id="clearSample">Clear sample</button></div></div>' +
      '<div class="ov-grid">' +
      statCard('💬', t.conversations || 0, 'conversations') +
      statCard('✉️', t.messages || 0, 'messages') +
      statCard('👥', t.uniqueVisitors || 0, 'unique visitors') +
      statCard('📥', t.leads || 0, 'leads captured') +
      '</div>' +
      '<div class="panel"><div class="panel-head"><h3>Messages per day</h3><span class="pill">Last 30 days</span></div><div class="panel-body">' +
      '<div class="bars">' + a.series.map((s) => '<div class="b" style="height:' + (s.messages ? Math.max(4, Math.round((s.messages / max) * 100)) : 2) + '%" title="' + s.date + ': ' + s.messages + ' messages, ' + s.leads + ' leads"><span class="tip">' + s.label + ' — ' + s.messages + ' msgs</span></div>').join('') + '</div>' +
      '</div></div>' +
      '<div class="two-col">' +
      '<div class="panel"><div class="panel-head"><h3>Feedback &amp; quality</h3></div><div class="panel-body">' +
      '<div class="row wrap" style="gap:22px">' +
      '<div><div class="k" style="font-size:13px;color:var(--ink-500);font-weight:600">👍 Positive</div><div style="font-size:28px;font-weight:800;color:var(--ok)">' + (t.upvotes || 0) + '</div></div>' +
      '<div><div class="k" style="font-size:13px;color:var(--ink-500);font-weight:600">👎 Negative</div><div style="font-size:28px;font-weight:800;color:var(--danger)">' + (t.downvotes || 0) + '</div></div>' +
      '<div><div class="k" style="font-size:13px;color:var(--ink-500);font-weight:600">Avg msgs / convo</div><div style="font-size:28px;font-weight:800">' + (t.avgPerConv || 0) + '</div></div>' +
      '<div><div class="k" style="font-size:13px;color:var(--ink-500);font-weight:600">Escalation rate</div><div style="font-size:28px;font-weight:800">' + escRate + '%</div></div>' +
      '</div>' +
      '<div class="mt-3"><div class="row-between mb-1"><span class="small muted">Escalations</span><span class="small">' + (t.escalated || 0) + ' escalated · ' + (t.resolved || 0) + ' resolved</span></div>' +
      '<div class="progress"><div style="width:' + (t.conversations ? Math.round((t.escalated / t.conversations) * 100) : 0) + '%"></div></div></div>' +
      '</div></div>' +
      '<div class="panel"><div class="panel-head"><h3>Top sources cited</h3></div><div class="panel-body">' +
      (a.topSources && a.topSources.length ? a.topSources.map((s, i) => '<div class="row-between" style="padding:8px 0;border-bottom:1px solid var(--line)"><span>' + (i + 1) + '. ' + esc(s.title) + '</span><span class="pill">' + s.count + '×</span></div>').join('') : '<p class="muted small">No citations recorded yet — answers cite their sources automatically.</p>') +
      '</div></div>' +
      '</div>';

    $('#loadSample', c).addEventListener('click', async () => {
      const r = await api('/chatbots/' + b.id + '/sample-data', { method: 'POST' });
      if (r.status === 200) { toast('Loaded ' + r.data.created + ' sample conversations', 'ok'); renderAnalytics(c); }
    });
    $('#clearSample', c).addEventListener('click', async () => {
      const r = await api('/chatbots/' + b.id + '/clear-sample-data', { method: 'POST' });
      if (r.status === 200) { toast('Sample data cleared', 'ok'); renderAnalytics(c); }
    });
  }

  // ---- embed ----
  function renderEmbed(c) {
    const b = state.bot;
    const snippet = '<script src="' + location.origin + '/widget.js"><\/script>\n<script>CoreAIWidget.init({ chatbotId: "' + b.id + '" });<\/script>';
    c.innerHTML =
      '<div class="page-head"><div><h1>Embed on your website</h1><p>Add your chatbot to any site with one snippet.</p></div></div>' +
      (b.training.chunksCount > 0 ? '' : '<div class="panel" style="background:var(--warn-soft);border-color:#fde68a"><div class="panel-body">⚠️ <b>Not trained yet.</b> You can still embed it, but it won\'t have answers until you <a class="link" href="#/b/' + b.id + '/training">add training data</a>.</div></div>') +
      '<div class="panel"><div class="panel-head"><h3>Installation snippet</h3><button class="btn btn-light btn-sm" id="copySnippet">📋 Copy</button></div><div class="panel-body"><div class="codeblock" id="snippet">' + esc(snippet) + '</div></div></div>' +
      '<div class="panel"><div class="panel-head"><h3>How it works</h3></div><div class="panel-body"><ol style="padding-left:20px;color:var(--ink-600)">' +
      '<li>Copy the snippet above.</li>' +
      '<li>Paste it just before the closing <code>&lt;/body&gt;</code> tag of your site.</li>' +
      '<li>Done — the widget appears with your bot\'s name, colors, logo, and quick prompts.</li>' +
      '</ol>' +
      '<div class="hint">The widget works on any site (HTTPS recommended). It inherits branding changes instantly — no code changes needed.</div></div></div>' +
      '<div class="panel"><div class="panel-head"><h3>Preview it here</h3></div><div class="panel-body"><button class="btn btn-primary" id="embedPreview">✨ Launch widget preview</button> <span class="small muted">Opens the real widget in the corner of this page.</span></div></div>';

    $('#copySnippet', c).addEventListener('click', async () => {
      try { await navigator.clipboard.writeText(snippet); toast('Copied to clipboard', 'ok'); }
      catch (e) {
        const ta = document.createElement('textarea'); ta.value = snippet; document.body.appendChild(ta); ta.select();
        document.execCommand('copy'); ta.remove(); toast('Copied to clipboard', 'ok');
      }
    });
    $('#embedPreview', c).addEventListener('click', () => {
      if (window.CoreAIWidget) {
        window.CoreAIWidget.init({ chatbotId: b.id });
        window.CoreAIWidget.open();
      }
    });
  }

  // ---- settings ----
  function renderSettings(c) {
    const b = state.bot;
    c.innerHTML =
      '<div class="page-head"><div><h1>Settings</h1><p>Behaviour, webhooks, and danger zone.</p></div><button class="btn btn-primary" id="saveSet">💾 Save</button></div>' +
      '<div class="panel"><div class="panel-body">' +
      '<div class="field"><label>Chatbot status</label><select class="select" id="setEnabled"><option value="1"' + (b.enabled !== false ? ' selected' : '') + '>Active — answering visitors</option><option value="0"' + (b.enabled === false ? ' selected' : '') + '>Paused — not responding</option></select>' +
      '<div class="hint">Pausing hides the launcher and stops replies while keeping your data.</div></div>' +
      '<div class="field"><label>Webhook URL <span class="pill">Live</span></label><input class="input mono" id="setWebhook" placeholder="https://your-app.com/hooks/coreai" value="' + esc(b.webhookUrl || '') + '">' +
      '<div class="hint">Core AI POSTs JSON here when a lead is captured or a visitor asks for a human. Events: <code>lead.captured</code>, <code>conversation.escalated</code>.</div></div>' +
      '</div></div>' +
      '<div class="panel" style="border-color:#fecaca"><div class="panel-head"><h3 style="color:var(--danger)">Danger zone</h3></div><div class="panel-body">' +
      '<div class="row-between"><div><div style="font-weight:600">Delete this chatbot</div><div class="small muted">Permanently removes training data, conversations, and leads.</div></div>' +
      '<button class="btn btn-danger" id="delBot">Delete chatbot</button></div></div></div>';

    $('#saveSet', c).addEventListener('click', async () => {
      const r = await api('/chatbots/' + b.id, { method: 'PATCH', body: { enabled: $('#setEnabled').value === '1', webhookUrl: $('#setWebhook').value.trim() } });
      if (r.status === 200) { state.bot = r.data.chatbot; toast('Saved', 'ok'); renderBotTopbar(); }
      else toast(r.data.error || 'Failed', 'err');
    });
    $('#delBot', c).addEventListener('click', () => deleteBot(b.id));
  }

  // ---------------- account pages ----------------
  function renderPlans() {
    const c = $('#content');
    const u = state.user;
    c.innerHTML =
      '<div class="page-head"><div><h1>Plans &amp; Billing</h1><p>You\'re on the <b>' + esc(u.plan) + '</b> plan (7-day free trial).</p></div></div>' +
      '<div class="panel"><div class="panel-head"><h3>Current plan</h3></div><div class="panel-body">' +
      '<div class="row-between wrap"><div><div style="font-weight:800;font-size:20px">' + esc(u.plan) + '</div><div class="muted small">Started ' + fmtDate(u.createdAt) + ' · 7-day trial</div></div>' +
      '<button class="btn btn-light" disabled>💳 Checkout coming soon</button></div>' +
      '<div class="hint mt-2">Billing is not wired up in this environment yet. Everything works on the free trial — to upgrade, <a class="link" href="mailto:sales@coreai.app">contact sales</a>.</div>' +
      '</div></div>' +
      '<div class="panel"><div class="panel-head"><h3>Plan comparison</h3></div><div class="panel-body" style="overflow-x:auto"><table class="table">' +
      '<thead><tr><th></th><th>Starter</th><th>Growth</th><th>Scale</th><th>Enterprise</th></tr></thead><tbody>' +
      planRow('Price', '$29/mo', '$79/mo', '$199/mo', 'Custom') +
      planRow('Chatbots', '1', 'Up to 3', 'Up to 10', 'Unlimited') +
      planRow('Training pages', '1,000', '10,000', '50,000', 'Custom') +
      planRow('Messages / month', '4k', '10k', '40k', 'Custom') +
      planRow('Analytics', 'Basic', 'Advanced', 'Advanced', 'Advanced') +
      planRow('API access', '—', '✓', '✓', '✓') +
      planRow('Webhooks', '—', '✓', '✓', '✓') +
      planRow('Auto refresh', 'Manual', 'Monthly', 'Daily', 'Daily') +
      planRow('SSO &amp; RBAC', '—', '—', '—', '✓') +
      '</tbody></table></div></div>';
  }
  function planRow(label, a, b, c2, d) {
    return '<tr><td style="font-weight:600">' + label + '</td><td>' + a + '</td><td>' + b + '</td><td>' + c2 + '</td><td>' + d + '</td></tr>';
  }

  async function renderApi() {
    const c = $('#content');
    const r = await api('/keys');
    const keys = r.data.keys || [];
    c.innerHTML =
      '<div class="page-head"><div><h1>API &amp; Integrations</h1><p>Connect Core AI to your own stack.</p></div></div>' +
      '<div class="panel"><div class="panel-head"><h3>API keys</h3><button class="btn btn-primary btn-sm" id="mkKey">＋ Generate key</button></div>' +
      '<div class="panel-body" style="padding:0">' +
      (keys.length
        ? '<table class="table"><tbody>' + keys.map((k) => '<tr><td class="mono">' + esc(k.key) + '</td><td class="muted">' + esc(k.label) + '</td><td class="muted small">Created ' + fmtDate(k.createdAt) + '</td><td><button class="icon-btn danger" data-del="' + esc(k.key) + '">🗑</button></td></tr>').join('') + '</tbody></table>'
        : '<p class="muted small" style="padding:20px">No API keys yet. Generate one to use the REST API.</p>') +
      '</div></div>' +
      '<div class="panel"><div class="panel-head"><h3>REST API (v1)</h3><p>Use your key as <code>Authorization: Bearer coreai_…</code></p></div><div class="panel-body">' +
      '<div class="codeblock"># List your chatbots\ncurl -H "Authorization: Bearer YOUR_KEY" ' + location.origin + '/api/v1/chatbots\n\n# Chat with a bot\ncurl -X POST -H "Authorization: Bearer YOUR_KEY" -H "Content-Type: application/json" \\\n  -d \'{"message":"Do you have a free trial?"}\' \\\n  ' + location.origin + '/api/v1/chatbots/{botId}/messages\n\n# List conversations\ncurl -H "Authorization: Bearer YOUR_KEY" ' + location.origin + '/api/v1/chatbots/{botId}/conversations\n\n# Retrain\ncurl -X POST -H "Authorization: Bearer YOUR_KEY" ' + location.origin + '/api/v1/chatbots/{botId}/retrain</div>' +
      '</div></div>' +
      '<div class="panel"><div class="panel-head"><h3>Integrations</h3></div><div class="panel-body"><div class="grid" style="grid-template-columns:repeat(auto-fill,minmax(280px,1fr))">' +
      integCard('🧩', 'Embed widget', 'One-line snippet for any website.', 'Live', '#embed-ready') +
      integCard('🔗', 'REST API', 'Create, chat, list, retrain — programmatically.', 'Live', '') +
      integCard('🪝', 'Webhooks', 'Push leads & escalations to your server.', 'Live', '') +
      integCard('📤', 'CSV export', 'Download leads as CSV.', 'Live', '') +
      integCard('💬', 'Slack', 'Answer questions in channels & DMs.', 'Coming soon', '') +
      integCard('🎧', 'Zendesk', 'Deflect tickets and escalate seamlessly.', 'Coming soon', '') +
      integCard('🟢', 'WhatsApp', 'Support customers in their favourite app.', 'Coming soon', '') +
      integCard('💌', 'Intercom', 'Chat in-app with human handoff.', 'Coming soon', '') +
      integCard('📁', 'Google Drive', 'Sync training docs from Drive.', 'Coming soon', '') +
      integCard('📚', 'Notion', 'Train on your Notion workspace.', 'Coming soon', '') +
      integCard('🐙', 'GitHub', 'Train on markdown docs in a repo.', 'Coming soon', '') +
      integCard('⚡', 'Zapier', 'Trigger workflows on new leads.', 'Coming soon', '') +
      '</div></div></div>';

    function integCard(ico, name, desc, status, href) {
      const live = status === 'Live';
      return '<div class="integration-card' + (live ? '' : ' soon') + '"><span class="ilogo">' + ico + '</span><div>' +
        '<h4>' + name + ' <span class="pill ' + (live ? 'pill-ok' : 'pill-warn') + '" style="margin-left:6px">' + status + '</span></h4>' +
        '<p>' + desc + '</p>' + (href ? '<div class="cta"><a class="link small" href="' + href + '">Set up →</a></div>' : '') +
        '</div></div>';
    }

    $('#mkKey', c).addEventListener('click', async () => {
      const m = modal('<div class="card-pad"><h3 style="margin-top:0">Generate API key</h3>' +
        '<div class="field"><label>Label</label><input class="input" id="keyLabel" placeholder="Production key"></div>' +
        '<div class="row" style="justify-content:flex-end;gap:10px"><button class="btn btn-ghost" id="kCancel">Cancel</button><button class="btn btn-primary" id="kCreate">Create</button></div></div>');
      $('#kCancel', m.content).addEventListener('click', m.close);
      $('#kCreate', m.content).addEventListener('click', async () => {
        const rr = await api('/keys', { method: 'POST', body: { label: $('#keyLabel').value.trim() || 'Default key' } });
        if (rr.status === 201) {
          m.close();
          const m2 = modal('<div class="card-pad"><h3 style="margin-top:0">Copy your key</h3><p class="muted">This is the only time it\'s shown in full.</p>' +
            '<div class="codeblock">' + esc(rr.data.key) + '</div>' +
            '<div class="row" style="justify-content:flex-end;gap:10px"><button class="btn btn-primary" id="kDone">Done</button></div></div>');
          $('#kDone', m2.content).addEventListener('click', () => { m2.close(); renderApi(); });
        } else toast(rr.data.error || 'Failed', 'err');
      });
    });
    $$('button[data-del]', c).forEach((btn) => btn.addEventListener('click', async () => {
      await api('/keys/' + btn.dataset.del, { method: 'DELETE' });
      renderApi();
    }));
  }

  function renderAccount() {
    const c = $('#content');
    const u = state.user;
    const llm = u.llm || {};
    c.innerHTML =
      '<div class="page-head"><div><h1>Account</h1><p>Your profile and AI model settings.</p></div></div>' +
      '<div class="panel"><div class="panel-head"><h3>Profile</h3></div><div class="panel-body">' +
      '<div class="field"><label>Name</label><input class="input" id="accName" value="' + esc(u.name) + '"></div>' +
      '<div class="field"><label>Email</label><input class="input" value="' + esc(u.email) + '" disabled><div class="hint">Email is fixed for this workspace.</div></div>' +
      '<button class="btn btn-primary" id="accSave">💾 Save</button></div></div>' +
      '<div class="panel"><div class="panel-head"><h3>AI model (optional)</h3><p>Connect an OpenAI-compatible model for generative answers. Without one, Core AI uses its built-in retrieval engine.</p></div><div class="panel-body">' +
      '<div class="field"><label>API base URL</label><input class="input mono" id="llmBase" placeholder="https://api.openai.com/v1" value="' + esc(llm.baseUrl || '') + '"></div>' +
      '<div class="field"><label>API key</label><input class="input mono" id="llmKey" type="password" placeholder="sk-…" value="' + esc(llm.apiKey || '') + '"><div class="hint">Stored server-side and never shown again after save.</div></div>' +
      '<div class="field"><label>Model</label><input class="input" id="llmModel" placeholder="gpt-4o-mini" value="' + esc(llm.model || '') + '"></div>' +
      '<div class="row"><button class="btn btn-primary" id="llmSave">💾 Save &amp; enable</button><button class="btn btn-light" id="llmTest">Test connection</button></div>' +
      '<div class="hint mt-2" id="llmTestResult"></div></div></div>';

    $('#accSave', c).addEventListener('click', async () => {
      const r = await api('/me', { method: 'PATCH', body: { name: $('#accName').value.trim() } });
      if (r.status === 200) { state.user = r.data.user; toast('Saved', 'ok'); renderShell(); }
    });
    $('#llmSave', c).addEventListener('click', async () => {
      const body = { name: state.user.name, llm: { baseUrl: $('#llmBase').value.trim(), apiKey: $('#llmKey').value.trim(), model: $('#llmModel').value.trim() } };
      const r = await api('/me', { method: 'PATCH', body });
      if (r.status === 200) { state.user = r.data.user; toast('AI model settings saved', 'ok'); }
    });
    $('#llmTest', c).addEventListener('click', async () => {
      const res = $('#llmTestResult');
      res.innerHTML = '<span class="spinner dark"></span> Testing…';
      const r = await api('/account/llm-test', { method: 'POST', body: { baseUrl: $('#llmBase').value.trim(), apiKey: $('#llmKey').value.trim(), model: $('#llmModel').value.trim() } });
      if (r.status === 200 && r.data.ok) res.innerHTML = '<span class="pill pill-ok">✓ Connected — sample reply: “' + esc(r.data.sample) + '”</span>';
      else res.innerHTML = '<span class="pill pill-danger">✕ Connection failed — check URL, key, and model. Retrieval engine still works.</span>';
    });
  }

  // ---------------- boot ----------------
  window.addEventListener('hashchange', route);
  window.addEventListener('load', route);
})();
