// PM2 process config — `pm2 start ecosystem.config.js`
module.exports = {
  apps: [
    {
      name: 'core-ai',
      script: 'server.js',
      instances: 1,               // single instance: state lives in data/*.json files
      exec_mode: 'fork',
      env: {
        NODE_ENV: 'production',
        PORT: 8080,
      },
      max_memory_restart: '300M',
      autorestart: true,
    },
  ],
};
